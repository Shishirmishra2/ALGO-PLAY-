export interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  subject: string;
  difficulty: "beginner" | "intermediate" | "expert";
}

export const questionPools: Record<string, Question[]> = {
  dsa: [
    {
      id: "dsa_1",
      question:
        "What is the time complexity of searching an element in a balanced Binary Search Tree (BST)?",
      options: ["O(n)", "O(log n)", "O(n log n)", "O(1)"],
      correctAnswer: "O(log n)",
      subject: "dsa",
      difficulty: "intermediate",
    },
    {
      id: "dsa_2",
      question: "Which data structure uses LIFO (Last In First Out) principle?",
      options: ["Queue", "Stack", "Array", "Linked List"],
      correctAnswer: "Stack",
      subject: "dsa",
      difficulty: "beginner",
    },
    {
      id: "dsa_3",
      question: "What is the worst-case time complexity of QuickSort?",
      options: ["O(n)", "O(n log n)", "O(n²)", "O(log n)"],
      correctAnswer: "O(n²)",
      subject: "dsa",
      difficulty: "intermediate",
    },
    {
      id: "dsa_4",
      question:
        "Which algorithm is used to find the shortest path in a weighted graph?",
      options: ["BFS", "DFS", "Dijkstra's", "Kruskal's"],
      correctAnswer: "Dijkstra's",
      subject: "dsa",
      difficulty: "expert",
    },
  ],
  os: [
    {
      id: "os_1",
      question: "What is a deadlock in operating systems?",
      options: [
        "Process termination",
        "Resource allocation problem",
        "Memory leak",
        "CPU scheduling issue",
      ],
      correctAnswer: "Resource allocation problem",
      subject: "os",
      difficulty: "intermediate",
    },
    {
      id: "os_2",
      question:
        "Which scheduling algorithm gives the shortest average waiting time?",
      options: ["FCFS", "SJF", "Round Robin", "Priority"],
      correctAnswer: "SJF",
      subject: "os",
      difficulty: "intermediate",
    },
    {
      id: "os_3",
      question: "What does the fork() system call return to the child process?",
      options: ["Process ID", "0", "-1", "1"],
      correctAnswer: "0",
      subject: "os",
      difficulty: "expert",
    },
  ],
  ai: [
    {
      id: "ai_1",
      question: "What is the main goal of machine learning?",
      options: [
        "Data storage",
        "Pattern recognition",
        "File compression",
        "Network security",
      ],
      correctAnswer: "Pattern recognition",
      subject: "ai",
      difficulty: "beginner",
    },
    {
      id: "ai_2",
      question: "Which algorithm is commonly used for decision trees?",
      options: ["K-means", "ID3", "Dijkstra", "Bubble Sort"],
      correctAnswer: "ID3",
      subject: "ai",
      difficulty: "intermediate",
    },
    {
      id: "ai_3",
      question: "What does backpropagation do in neural networks?",
      options: [
        "Forward pass",
        "Weight initialization",
        "Error propagation",
        "Data preprocessing",
      ],
      correctAnswer: "Error propagation",
      subject: "ai",
      difficulty: "expert",
    },
  ],
  dbms: [
    {
      id: "dbms_1",
      question: "What does ACID stand for in database transactions?",
      options: [
        "Atomic, Consistent, Isolated, Durable",
        "Advanced, Complete, Independent, Direct",
        "Automatic, Controlled, Internal, Dynamic",
        "Applied, Centralized, Integrated, Distributed",
      ],
      correctAnswer: "Atomic, Consistent, Isolated, Durable",
      subject: "dbms",
      difficulty: "intermediate",
    },
    {
      id: "dbms_2",
      question: "Which normal form eliminates transitive dependencies?",
      options: ["1NF", "2NF", "3NF", "BCNF"],
      correctAnswer: "3NF",
      subject: "dbms",
      difficulty: "intermediate",
    },
    {
      id: "dbms_3",
      question: "What is a primary key?",
      options: [
        "First column",
        "Unique identifier",
        "Foreign reference",
        "Index key",
      ],
      correctAnswer: "Unique identifier",
      subject: "dbms",
      difficulty: "beginner",
    },
  ],
};

export const getQuestionsForSubjects = (
  subjects: string[],
  difficulty?: string,
  count: number = 10
): Question[] => {
  if (subjects.length === 0) {
    // Default to DSA if no subjects selected
    subjects = ["dsa"];
  }

  let allQuestions: Question[] = [];

  // Collect questions from selected subjects
  subjects.forEach((subject) => {
    if (questionPools[subject]) {
      allQuestions = [...allQuestions, ...questionPools[subject]];
    }
  });

  // Filter by difficulty if specified
  if (difficulty && difficulty !== "all") {
    allQuestions = allQuestions.filter((q) => q.difficulty === difficulty);
  }

  // Shuffle and return requested count
  const shuffled = allQuestions.sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
};
