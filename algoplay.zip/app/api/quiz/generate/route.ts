import { NextRequest, NextResponse } from "next/server";
import { generateQuizQuestions } from "@/lib/geminiQuiz";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { subjects, difficulty = "intermediate", count = 10 } = body;

    // Validation
    if (!subjects || !Array.isArray(subjects) || subjects.length === 0) {
      return NextResponse.json(
        { error: "At least one subject must be selected" },
        { status: 400 }
      );
    }

    if (count < 1 || count > 20) {
      return NextResponse.json(
        { error: "Question count must be between 1 and 20" },
        { status: 400 }
      );
    }

    const validDifficulties = ["beginner", "intermediate", "expert"];
    if (!validDifficulties.includes(difficulty)) {
      return NextResponse.json(
        { error: "Difficulty must be beginner, intermediate, or expert" },
        { status: 400 }
      );
    }

    // Check if Gemini API key is configured
    if (!process.env.GOOGLE_GEMINI_API_KEY) {
      console.error("GOOGLE_GEMINI_API_KEY is not configured");
      return NextResponse.json(
        { error: "Quiz generation service is not properly configured" },
        { status: 500 }
      );
    }

    console.log(
      `Generating ${count} ${difficulty} questions for subjects: ${subjects.join(
        ", "
      )}`
    );

    // Generate questions using Gemini
    const questions = await generateQuizQuestions(subjects, difficulty, count);

    if (!questions || questions.length === 0) {
      throw new Error("No questions were generated");
    }

    console.log(`Successfully generated ${questions.length} questions`);

    return NextResponse.json({
      questions,
      metadata: {
        generated_at: new Date().toISOString(),
        subjects: subjects,
        difficulty: difficulty,
        count: questions.length,
        generated_by: "gemini",
      },
    });
  } catch (error: any) {
    console.error("Error in quiz generation API:", error);

    // Provide more specific error messages
    let errorMessage = "Failed to generate quiz questions";
    let statusCode = 500;

    if (error.message.includes("API key")) {
      errorMessage = "Quiz service is not properly configured";
    } else if (
      error.message.includes("quota") ||
      error.message.includes("limit")
    ) {
      errorMessage =
        "Quiz service is temporarily unavailable due to high demand";
    } else if (error.message.includes("timeout")) {
      errorMessage = "Quiz generation timed out. Please try again";
    } else if (error.message.includes("JSON")) {
      errorMessage = "Error processing quiz data. Please try again";
    }

    return NextResponse.json(
      {
        error: errorMessage,
        details:
          process.env.NODE_ENV === "development" ? error.message : undefined,
      },
      { status: statusCode }
    );
  }
}
