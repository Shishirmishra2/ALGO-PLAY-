"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { ArrowLeftIcon, CaretRightIcon } from "@phosphor-icons/react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Navbar from "@/components/Navbar";

export default function Profile() {
  const [user, setUser] = useState<any>(null);
  const [darkMode, setDarkMode] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const getUser = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      setUser(user);
    };
    getUser();
  }, []);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push("/");
  };

  const getUserInitials = () => {
    if (!user?.user_metadata?.first_name || !user?.user_metadata?.last_name) {
      return user?.email?.charAt(0).toUpperCase() || "U";
    }
    return `${user.user_metadata.first_name.charAt(
      0
    )}${user.user_metadata.last_name.charAt(0)}`;
  };

  const getUserDisplayName = () => {
    if (user?.user_metadata?.first_name && user?.user_metadata?.last_name) {
      return `${user.user_metadata.first_name} ${user.user_metadata.last_name}`;
    }
    return user?.email || "User";
  };

  return (
    <div className="min-h-screen text-white p-6 pb-24">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="flex items-center mb-8">
          <Button
            variant="ghost"
            size="icon"
            className="text-white hover:bg-white/10 mr-4"
            asChild>
            <Link href="/dashboard">
              <ArrowLeftIcon size={24} />
            </Link>
          </Button>
          <h1 className="text-xl font-semibold">User Profile</h1>
        </div>

        {/* Profile Section */}
        <div className="text-center mb-8">
          <div className="relative inline-block mb-4">
            <Avatar className="w-24 h-24 ring-4 ring-purple-500">
              <AvatarImage src="" alt={getUserDisplayName()} />
              <AvatarFallback className="text-xl bg-purple-600 text-white">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            <div className="absolute bottom-0 right-0 bg-purple-500 rounded-full p-2">
              <div className="flex gap-1">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            </div>
          </div>
          <h2 className="text-2xl font-bold">{getUserDisplayName()}</h2>
        </div>

        {/* General Section */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4 text-gray-300">General</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 flex items-center justify-center">
                  <svg
                    className="w-5 h-5"
                    fill="currentColor"
                    viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span>My Account</span>
              </div>
              <CaretRightIcon size={20} className="text-gray-400" />
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 flex items-center justify-center">
                  <svg
                    className="w-5 h-5"
                    fill="currentColor"
                    viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M4 4a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2H4zm2 6a2 2 0 114 0 2 2 0 01-4 0zm6 0a2 2 0 114 0 2 2 0 01-4 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span>Quiz History</span>
              </div>
              <CaretRightIcon size={20} className="text-gray-400" />
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 flex items-center justify-center">
                  <svg
                    className="w-5 h-5"
                    fill="currentColor"
                    viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span>FAQ & Support</span>
              </div>
              <CaretRightIcon size={20} className="text-gray-400" />
            </div>
          </div>
        </div>

        {/* Settings Section */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4 text-gray-300">Settings</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 flex items-center justify-center">
                  <svg
                    className="w-5 h-5"
                    fill="currentColor"
                    viewBox="0 0 20 20">
                    <path
                      fillRule="evenodd"
                      d="M7 2a1 1 0 011 1v1h3a1 1 0 110 2H9.578a.97.97 0 01-.748-.356L8.5 5H7V3a1 1 0 011-1zM3.5 6A1.5 1.5 0 015 4.5h.5v2A1.5 1.5 0 017 8h6a1.5 1.5 0 001.5-1.5v-2H15A1.5 1.5 0 0116.5 6v8a1.5 1.5 0 01-1.5 1.5H5A1.5 1.5 0 013.5 14V6z"
                      clipRule="evenodd"
                    />
                  </svg>
                </div>
                <span>Language</span>
              </div>
              <CaretRightIcon size={20} className="text-gray-400" />
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg bg-white/5">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 flex items-center justify-center">
                  <svg
                    className="w-5 h-5"
                    fill="currentColor"
                    viewBox="0 0 20 20">
                    <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
                  </svg>
                </div>
                <span>Dark Mode</span>
              </div>
              <Switch
                checked={darkMode}
                onCheckedChange={setDarkMode}
                className="data-[state=checked]:bg-purple-600"
              />
            </div>
          </div>
        </div>

        {/* Logout Button */}
        <Button
          onClick={handleLogout}
          variant="destructive"
          className="w-full bg-red-600 hover:bg-red-700">
          Logout
        </Button>
      </div>
      <Navbar />
    </div>
  );
}
