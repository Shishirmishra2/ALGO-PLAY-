# quiz_logic_backend.py
import os
import json
import random
import pandas as pd
import chromadb
from chromadb.utils import embedding_functions
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.prompts import ChatPromptTemplate
from fastapi import HTTPException
from dotenv import load_dotenv
import re

# Load environment variables from .env file
load_dotenv()

# Setup storage path and collection
# Use a path that is accessible by your FastAPI app
storage_path = "./chromadb_storage"
os.makedirs(storage_path, exist_ok=True)
client = chromadb.PersistentClient(path=storage_path)

# Load dataset (make sure this CSV is in the same directory as this file)
csv_path = "Software Questions.csv" 
try:
    data = pd.read_csv(csv_path, encoding="latin1")
    questions = data["Question"].tolist()
    answers = data["Answer"].tolist()
except FileNotFoundError:
    raise RuntimeError(f"CSV file not found at: {csv_path}. Please make sure it's in the correct directory.")
except Exception as e:
    raise RuntimeError(f"Error loading CSV file: {e}")

# Setup embedding function and collection
embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(model_name="all-MiniLM-L6-v2")

try:
    collection = client.get_collection(name="interview_question", embedding_function=embedding_fn)
    print("Found existing collection.")
except Exception:
    print("Collection not found. Creating a new one...")
    collection = client.create_collection(name="interview_question", embedding_function=embedding_fn)
    
    # Add documents in batches to avoid potential issues
    batch_size = 100
    for i in range(0, len(questions), batch_size):
        batch_questions = questions[i:i+batch_size]
        batch_answers = answers[i:i+batch_size]
        
        collection.add(
            documents=batch_answers,
            metadatas=[{"question": question} for question in batch_questions],
            ids=[f"id_{j}" for j in range(i, min(i+batch_size, len(questions)))]
        )
    print(f"Added {len(questions)} questions to the collection.")
    
# Setup LLM
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if not GOOGLE_API_KEY:
    raise ValueError("GOOGLE_API_KEY not found in environment variables or .env file.")

os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY
llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.3)

def clean_json_response(response_text: str) -> str:
    """
    Clean the response text to extract valid JSON
    """
    # Remove markdown code blocks
    response_text = re.sub(r'```json\s*', '', response_text)
    response_text = re.sub(r'```\s*', '', response_text)
    
    # Remove leading/trailing whitespace
    response_text = response_text.strip()
    
    # Try to find JSON content between braces
    json_match = re.search(r'\{.*\}', response_text, re.DOTALL)
    if json_match:
        return json_match.group(0)
    
    return response_text

def get_mcq_from_topic(topic: str, difficulty_level: int):
    """
    Retrieves a relevant question from ChromaDB and uses an LLM to generate an MCQ.
    """
    print(f"🎯 Starting MCQ generation for topic: '{topic}', difficulty: {difficulty_level}")
    
    # Validate inputs
    if not topic or not topic.strip():
        print("❌ Empty topic provided")
        raise HTTPException(status_code=400, detail="Topic cannot be empty.")
    
    if difficulty_level not in [1, 2, 3, 4, 5]:
        print(f"❌ Invalid difficulty level: {difficulty_level}")
        raise HTTPException(status_code=400, detail="Difficulty level must be between 1 and 5.")
    
    # Retrieve relevant question from ChromaDB
    try:
        print("🔍 Querying ChromaDB...")
        query_result = collection.query(query_texts=[topic.strip()], n_results=3)
        print(f"📊 ChromaDB query completed. Results: {len(query_result.get('documents', [[]]))} documents")
        
        if not query_result['documents'] or not query_result['documents'][0]:
            print(f"❌ No documents found for topic: {topic}")
            raise HTTPException(status_code=404, detail=f"No relevant questions found for the topic: '{topic}'.")
        
        # Select a random context from the top results
        available_contexts = query_result['documents'][0]
        context = random.choice(available_contexts)
        print(f"✅ Selected context (length: {len(context)} chars): {context[:100]}...")
        
    except HTTPException:
        raise  # Re-raise HTTP exceptions
    except Exception as e:
        print(f"❌ ChromaDB error: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    
    # Generate MCQ with improved prompt
    print("🤖 Generating MCQ with AI...")
    
    mcq_prompt = ChatPromptTemplate.from_messages([
        ("system", """You are an expert quiz maker. Create a multiple-choice question based on the given topic and context.
        
        IMPORTANT: Return ONLY valid JSON with this exact structure:
        {{
            "question": "Your question here?",
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "correct_answer": "The exact correct option from the options array",
            "explanation": "Brief explanation of why this answer is correct"
        }}
        
        Do not include any markdown formatting, code blocks, or extra text outside the JSON."""),
        ("user", """Topic: {topic}
Context: {context}
Difficulty Level: {difficulty} (1=Easy, 5=Very Hard)

Generate a {difficulty_word} level multiple-choice question with 4 options.""")
    ])
    
    # Map difficulty level to words
    difficulty_words = {1: "easy", 2: "moderate", 3: "intermediate", 4: "hard", 5: "very hard"}
    difficulty_word = difficulty_words.get(difficulty_level, "intermediate")
    
    try:
        chain = mcq_prompt | llm
        
        print(f"📤 Sending request to AI model...")
        raw_output = chain.invoke({
            "topic": topic, 
            "context": context, 
            "difficulty": difficulty_level,
            "difficulty_word": difficulty_word
        })
        
        print(f"📥 Received AI response (length: {len(raw_output.content)} chars)")
        print(f"🔍 Raw response: {raw_output.content[:200]}...")
        
        # Clean and parse the response
        cleaned_content = clean_json_response(raw_output.content)
        print(f"🧹 Cleaned JSON content: {cleaned_content[:200]}...")
        
        mcq = json.loads(cleaned_content)
        print("✅ JSON parsing successful")
        
        # Validate the structure
        required_keys = ["question", "options", "correct_answer", "explanation"]
        if not all(key in mcq for key in required_keys):
            missing_keys = [key for key in required_keys if key not in mcq]
            print(f"❌ Missing keys: {missing_keys}")
            raise ValueError(f"Missing required keys: {missing_keys}")
        
        if not isinstance(mcq["options"], list):
            print(f"❌ Options is not a list: {type(mcq['options'])}")
            raise ValueError("Options must be a list")
            
        if len(mcq["options"]) != 4:
            print(f"❌ Wrong number of options: {len(mcq['options'])}")
            raise ValueError(f"Options must have exactly 4 items, got {len(mcq['options'])}")
        
        if mcq["correct_answer"] not in mcq["options"]:
            print(f"❌ Correct answer not in options: '{mcq['correct_answer']}'")
            print(f"   Available options: {mcq['options']}")
            raise ValueError("Correct answer must be one of the provided options")
            
        print("✅ MCQ validation successful")
            
    except json.JSONDecodeError as e:
        print(f"❌ JSON Decode Error: {e}")
        print(f"📄 Raw Output: {raw_output.content}")
        print(f"📄 Cleaned Content: {cleaned_content}")
        raise HTTPException(status_code=500, detail=f"JSON parsing failed: {str(e)}")
    except ValueError as e:
        print(f"❌ Validation Error: {e}")
        raise HTTPException(status_code=500, detail=f"Invalid question format: {str(e)}")
    except Exception as e:
        print(f"❌ Unexpected AI error: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"AI generation error: {str(e)}")
    
    # Shuffle options to randomize answer position
    correct_answer = mcq['correct_answer']
    random.shuffle(mcq['options'])
    
    # Assign a unique ID to the question
    mcq['id'] = str(random.randint(10000, 99999))
    mcq['topic'] = topic
    mcq['difficulty_level'] = difficulty_level
    
    print(f"🎉 MCQ generation completed successfully! ID: {mcq['id']}")
    return mcq

# Additional utility function for testing
def test_mcq_generation(topic: str = "Python programming", difficulty: int = 3):
    """
    Test function to verify MCQ generation works
    """
    try:
        result = get_mcq_from_topic(topic, difficulty)
        print("Test successful!")
        print(json.dumps(result, indent=2))
        return result
    except Exception as e:
        print(f"Test failed: {e}")
        return None

# Example usage and testing
if __name__ == "__main__":
    # Test the function
    test_result = test_mcq_generation("data structures", 2)
    if test_result:
        print("Backend is working correctly!")
    else:
        print("Backend needs debugging.")