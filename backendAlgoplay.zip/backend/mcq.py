# debug_mcq.py
import os
import sys
import json
import pandas as pd
import chromadb
from chromadb.utils import embedding_functions
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def debug_step_by_step():
    """Debug each component step by step"""
    
    print("🔍 Starting debug process...\n")
    
    # Step 1: Check CSV file
    print("1️⃣ Checking CSV file...")
    csv_path = "Software Questions.csv"
    try:
        if not os.path.exists(csv_path):
            print(f"❌ CSV file not found at: {csv_path}")
            print("📁 Current directory contents:")
            for file in os.listdir("."):
                if file.endswith('.csv'):
                    print(f"   - {file}")
            return False
        
        data = pd.read_csv(csv_path, encoding="latin1")
        print(f"✅ CSV loaded successfully! Shape: {data.shape}")
        print(f"   Columns: {list(data.columns)}")
        print(f"   Sample question: {data.iloc[0]['Question'][:100]}...")
        
    except Exception as e:
        print(f"❌ Error loading CSV: {e}")
        return False
    
    # Step 2: Check environment variables
    print("\n2️⃣ Checking environment variables...")
    google_api_key = os.getenv("GOOGLE_API_KEY")
    if not google_api_key:
        print("❌ GOOGLE_API_KEY not found in environment")
        print("💡 Make sure you have a .env file with GOOGLE_API_KEY=your_key")
        return False
    else:
        print(f"✅ GOOGLE_API_KEY found (length: {len(google_api_key)})")
    
    # Step 3: Test ChromaDB
    print("\n3️⃣ Testing ChromaDB...")
    try:
        storage_path = "./chromadb_storage"
        client = chromadb.PersistentClient(path=storage_path)
        embedding_fn = embedding_functions.SentenceTransformerEmbeddingFunction(
            model_name="all-MiniLM-L6-v2"
        )
        
        try:
            collection = client.get_collection(
                name="interview_question", 
                embedding_function=embedding_fn
            )
            print("✅ ChromaDB collection found")
            
            # Test query
            query_result = collection.query(
                query_texts=["Python programming"], 
                n_results=1
            )
            print(f"✅ ChromaDB query successful! Found {len(query_result['documents'][0])} results")
            if query_result['documents'][0]:
                print(f"   Sample result: {query_result['documents'][0][0][:100]}...")
                
        except Exception as e:
            print(f"❌ ChromaDB collection issue: {e}")
            return False
            
    except Exception as e:
        print(f"❌ ChromaDB connection failed: {e}")
        return False
    
    # Step 4: Test Google AI
    print("\n4️⃣ Testing Google AI connection...")
    try:
        from langchain_google_genai import ChatGoogleGenerativeAI
        from langchain.prompts import ChatPromptTemplate
        
        os.environ["GOOGLE_API_KEY"] = google_api_key
        llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.3)
        
        # Simple test
        simple_prompt = ChatPromptTemplate.from_messages([
            ("user", "Say 'Hello, I am working!' in JSON format like: {{\"message\": \"Hello, I am working!\"}}")
        ])
        
        chain = simple_prompt | llm
        response = chain.invoke({})
        print(f"✅ Google AI connection successful!")
        print(f"   Response: {response.content[:100]}...")
        
    except Exception as e:
        print(f"❌ Google AI connection failed: {e}")
        print(f"   Error type: {type(e).__name__}")
        return False
    
    # Step 5: Test full MCQ generation
    print("\n5️⃣ Testing full MCQ generation...")
    try:
        from quiz_logic_backend import get_mcq_from_topic
        
        # Try with a simple topic
        result = get_mcq_from_topic("Python", 2)
        print("✅ MCQ generation successful!")
        print(f"   Generated question: {result['question'][:100]}...")
        print(f"   Number of options: {len(result['options'])}")
        
    except Exception as e:
        print(f"❌ MCQ generation failed: {e}")
        print(f"   Error type: {type(e).__name__}")
        import traceback
        print(f"   Full traceback:\n{traceback.format_exc()}")
        return False
    
    print("\n🎉 All debugging steps passed!")
    return True

def check_file_structure():
    """Check if all required files exist"""
    print("\n📂 Checking file structure...")
    
    required_files = [
        "quiz_logic_backend.py",
        "main.py",  # or whatever you named your FastAPI file
        ".env",
        "Software Questions.csv"
    ]
    
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file} - Found")
        else:
            print(f"❌ {file} - Missing")
    
    print(f"\n📁 Current directory: {os.getcwd()}")
    print("📄 All files in directory:")
    for file in sorted(os.listdir(".")):
        print(f"   - {file}")

def test_minimal_generation():
    """Test with minimal setup"""
    print("\n🧪 Testing minimal MCQ generation...")
    
    try:
        # Direct test without FastAPI
        from quiz_logic_backend import test_mcq_generation
        
        result = test_mcq_generation("Python", 2)
        if result:
            print("✅ Direct test successful!")
            print(json.dumps(result, indent=2))
        else:
            print("❌ Direct test failed")
            
    except Exception as e:
        print(f"❌ Minimal test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    print("🚀 MCQ Generation Debug Tool\n")
    
    # Run all debug steps
    check_file_structure()
    
    if debug_step_by_step():
        test_minimal_generation()
    else:
        print("\n❌ Debug failed. Please fix the issues above and try again.")
        
    print("\n🏁 Debug completed!")