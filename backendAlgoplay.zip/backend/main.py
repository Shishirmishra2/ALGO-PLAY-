# main.py (or app.py)
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import uvicorn
from quiz_logic_backend import get_mcq_from_topic, test_mcq_generation

# Create FastAPI app
app = FastAPI(
    title="Quiz Generation API",
    description="API for generating multiple choice questions from topics",
    version="1.0.0"
)

# Pydantic models for request/response
class QuizRequest(BaseModel):
    topic: str
    difficulty_level: int = 3

class MCQResponse(BaseModel):
    id: str
    question: str
    options: List[str]
    correct_answer: str
    explanation: str
    topic: str
    difficulty_level: int

class ErrorResponse(BaseModel):
    detail: str

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Quiz Generation API", 
        "version": "1.0.0",
        "endpoints": {
            "/": "This root endpoint",
            "/generate-mcq": "POST - Generate MCQ from topic",
            "/test": "GET - Test the MCQ generation",
            "/health": "GET - Health check",
            "/docs": "Interactive API documentation"
        }
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy", "message": "Quiz API is running"}

# Generate MCQ endpoint
@app.post("/generate-mcq", response_model=MCQResponse)
async def generate_mcq(request: QuizRequest):
    """
    Generate a multiple choice question based on topic and difficulty level.
    
    - **topic**: The subject/topic for the question
    - **difficulty_level**: Integer from 1 (easy) to 5 (very hard)
    """
    try:
        # Validate difficulty level
        if not 1 <= request.difficulty_level <= 5:
            raise HTTPException(
                status_code=400, 
                detail="Difficulty level must be between 1 and 5"
            )
        
        # Generate MCQ using the backend function
        mcq = get_mcq_from_topic(request.topic, request.difficulty_level)
        
        return MCQResponse(**mcq)
        
    except HTTPException:
        # Re-raise HTTP exceptions from the backend
        raise
    except Exception as e:
        # Handle any unexpected errors
        raise HTTPException(
            status_code=500, 
            detail=f"Internal server error: {str(e)}"
        )

# Test endpoint
@app.get("/test")
async def test_endpoint():
    """Test the MCQ generation with a sample topic"""
    try:
        result = test_mcq_generation("Python programming", 2)
        if result:
            return {
                "status": "success", 
                "message": "Test completed successfully",
                "sample_mcq": result
            }
        else:
            return {
                "status": "failed", 
                "message": "Test failed - check server logs"
            }
    except Exception as e:
        raise HTTPException(
            status_code=500, 
            detail=f"Test failed: {str(e)}"
        )

# Get available topics endpoint (optional)
@app.get("/topics")
async def get_sample_topics():
    """Get some sample topics that work well with the system"""
    return {
        "sample_topics": [
            "Python programming",
            "Data structures",
            "Machine learning",
            "Web development",
            "Database management",
            "Object-oriented programming",
            "Software testing",
            "Algorithms",
            "Network security",
            "Cloud computing"
        ],
        "difficulty_levels": {
            "1": "Easy - Basic concepts",
            "2": "Moderate - Some experience needed",
            "3": "Intermediate - Good understanding required",
            "4": "Hard - Advanced knowledge needed",
            "5": "Very Hard - Expert level"
        }
    }

# Error handlers
@app.exception_handler(404)
async def not_found_handler(request, exc):
    return {"detail": "Endpoint not found. Visit /docs for available endpoints."}

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    return {"detail": "Internal server error. Please try again later."}

# Run the app
if __name__ == "__main__":
    uvicorn.run(
        "main:app",  # Change to your filename if different
        host="127.0.0.1",
        port=8000,
        reload=True
    )