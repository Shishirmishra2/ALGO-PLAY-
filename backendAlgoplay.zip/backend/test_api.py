# test_api.py
import requests
import json

# Base URL for your API
BASE_URL = "http://127.0.0.1:8000"

def test_root_endpoint():
    """Test the root endpoint"""
    print("🧪 Testing root endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/")
        if response.status_code == 200:
            print("✅ Root endpoint working!")
            print(json.dumps(response.json(), indent=2))
        else:
            print(f"❌ Root endpoint failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Error testing root endpoint: {e}")
    print("-" * 50)

def test_health_endpoint():
    """Test the health check endpoint"""
    print("🏥 Testing health endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/health")
        if response.status_code == 200:
            print("✅ Health check working!")
            print(json.dumps(response.json(), indent=2))
        else:
            print(f"❌ Health check failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Error testing health endpoint: {e}")
    print("-" * 50)

def test_mcq_generation():
    """Test MCQ generation"""
    print("📝 Testing MCQ generation...")
    try:
        # Test data
        test_data = {
            "topic": "Python programming",
            "difficulty_level": 3
        }
        
        response = requests.post(
            f"{BASE_URL}/generate-mcq",
            json=test_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 200:
            print("✅ MCQ generation working!")
            mcq = response.json()
            print(f"Question: {mcq['question']}")
            print(f"Options: {mcq['options']}")
            print(f"Correct Answer: {mcq['correct_answer']}")
            print(f"Explanation: {mcq['explanation']}")
        else:
            print(f"❌ MCQ generation failed: {response.status_code}")
            print(response.json())
    except Exception as e:
        print(f"❌ Error testing MCQ generation: {e}")
    print("-" * 50)

def test_invalid_difficulty():
    """Test invalid difficulty level"""
    print("🚫 Testing invalid difficulty level...")
    try:
        test_data = {
            "topic": "Python programming",
            "difficulty_level": 10  # Invalid
        }
        
        response = requests.post(
            f"{BASE_URL}/generate-mcq",
            json=test_data,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code == 400:
            print("✅ Invalid difficulty handling working!")
            print(json.dumps(response.json(), indent=2))
        else:
            print(f"❌ Expected 400, got: {response.status_code}")
    except Exception as e:
        print(f"❌ Error testing invalid difficulty: {e}")
    print("-" * 50)

def test_topics_endpoint():
    """Test the topics endpoint"""
    print("📚 Testing topics endpoint...")
    try:
        response = requests.get(f"{BASE_URL}/topics")
        if response.status_code == 200:
            print("✅ Topics endpoint working!")
            topics = response.json()
            print(f"Sample topics: {topics['sample_topics'][:3]}...")
        else:
            print(f"❌ Topics endpoint failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Error testing topics endpoint: {e}")
    print("-" * 50)

if __name__ == "__main__":
    print("🚀 Starting API Tests...\n")
    
    # Run all tests
    test_root_endpoint()
    test_health_endpoint()
    test_topics_endpoint()
    test_mcq_generation()
    test_invalid_difficulty()
    
    print("🏁 All tests completed!")
    print("\n💡 Tip: Visit http://127.0.0.1:8000/docs for interactive API documentation")